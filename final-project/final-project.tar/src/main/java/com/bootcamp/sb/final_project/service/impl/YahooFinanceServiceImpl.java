package com.bootcamp.sb.final_project.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bootcamp.sb.final_project.entity.StockPriceEntity;
import com.bootcamp.sb.final_project.entity.mapper.EntityMapper;
import com.bootcamp.sb.final_project.lib.YahooFinanceManager;
import com.bootcamp.sb.final_project.model.TStockRecordType;
import com.bootcamp.sb.final_project.model.dto.YahooFinanceDto;
import com.bootcamp.sb.final_project.service.TStockPriceService;
import com.bootcamp.sb.final_project.service.TStockService;
import com.bootcamp.sb.final_project.service.YahooFinanceService;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public class YahooFinanceServiceImpl implements YahooFinanceService {
  @Autowired
  private TStockService tStockService;

  @Autowired
  private TStockPriceService tStockPriceService;

  @Autowired
  private YahooFinanceManager yahooFinanceManager;

  @Autowired
  private EntityMapper entityMapper;

  @Override
  public void fetchStockPrice(TStockRecordType type) throws JsonProcessingException {
    List<String> symbols = this.tStockService.findAllSymbols();

    YahooFinanceDto dto = yahooFinanceManager.getQuote(symbols);

    List<StockPriceEntity> prices = this.entityMapper.map(dto, type);

    for (StockPriceEntity price : prices) {
      if (!this.tStockPriceService.isDataExist(price.getSymbol(), type, price.getRegularMarketTime()))
        this.tStockPriceService.create(price);
    }
  }
}
