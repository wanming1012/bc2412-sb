package com.bootcamp.sb.final_project.controller;

import com.bootcamp.sb.final_project.model.dto.YahooFinanceDto;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


public interface QuoteOperation {
  @GetMapping(value = "/quote")
  YahooFinanceDto getQuote(@RequestParam List<String> symbols);
}
