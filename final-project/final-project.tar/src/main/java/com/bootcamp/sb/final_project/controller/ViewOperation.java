package com.bootcamp.sb.final_project.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.bootcamp.sb.final_project.model.TStockRecordType;

public interface ViewOperation {
  @GetMapping(value = "/linechart")
  String lineChart(@RequestParam String symbol, @RequestParam TStockRecordType type, Model model);
}
