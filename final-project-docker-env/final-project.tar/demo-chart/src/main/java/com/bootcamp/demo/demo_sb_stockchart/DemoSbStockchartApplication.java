package com.bootcamp.demo.demo_sb_stockchart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSbStockchartApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSbStockchartApplication.class, args);
	}

}
