package com.bootcamp.demo.demo_sb_stockchart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSbStockchartApplicationTests {

	@Test
	void contextLoads() {
	}

}
