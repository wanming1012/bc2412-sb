package com.bootcamp.sb.final_project.controller.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.bootcamp.sb.final_project.controller.QuoteOperation;
import com.bootcamp.sb.final_project.lib.YahooFinanceManager;
import com.bootcamp.sb.final_project.model.dto.YahooFinanceDto;

@RestController
@RequestMapping(value = "/v1")
public class QuoteController implements QuoteOperation {
  @Autowired
  private YahooFinanceManager yahooFinanceManager;

  @Override
  public YahooFinanceDto getQuote(List<String> symbols) {
    return this.yahooFinanceManager.getQuote(symbols);
  }
}
