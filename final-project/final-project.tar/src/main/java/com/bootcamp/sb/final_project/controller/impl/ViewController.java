package com.bootcamp.sb.final_project.controller.impl;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.bootcamp.sb.final_project.controller.ViewOperation;
import com.bootcamp.sb.final_project.model.TStockRecordType;

@Controller
@RequestMapping(value = "/v1")
public class ViewController implements ViewOperation {
  @Override
  public String lineChart(String symbol, TStockRecordType type, Model model) {
    model.addAttribute("symbol", symbol);
    model.addAttribute("type", type.getValue());
    return "linechart";
  }
}
